"""
3D Batch Optimizer - Blender Addon (with WebP Support)
Batch optimize GLB, GLTF, and VRM files with texture downscaling and smart compression.

Based on: https://github.com/DOCTORdripp/blender-3d-batch-optimizer
Enhanced with WebP texture format support for Blender 3.4+/4.x/5.x

Note: VRM files use JPEG instead of WebP, as most VRM viewers/engines
do not support WebP textures.
"""

bl_info = {
    "name": "3D Batch Optimizer",
    "author": "DOCTORdripp (WebP enhancement by Claude)",
    "version": (2, 1, 0),
    "blender": (3, 4, 0),
    "location": "View3D > Sidebar > 3D Batch Optimizer",
    "description": "Batch optimize GLB, GLTF, and VRM files with texture downscaling (JPEG/PNG/WebP)",
    "warning": "",
    "doc_url": "https://github.com/DOCTORdripp/blender-3d-batch-optimizer",
    "category": "Import-Export",
}

import bpy
import os
import sys
import traceback
from pathlib import Path
from bpy.props import (
    StringProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
)


# ================================
# CORE OPTIMIZER FUNCTIONS
# ================================

def log(message, level="INFO"):
    """Print formatted log message."""
    print(f"[{level}] {message}")


def is_webp_supported():
    """Check if current Blender version supports WebP (3.4+)."""
    return bpy.app.version >= (3, 4, 0)


def clear_scene():
    """Clear all objects, materials, and images from the current scene."""
    try:
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete(use_global=False)

        for block in bpy.data.meshes:
            bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            bpy.data.materials.remove(block)
        for block in bpy.data.images:
            bpy.data.images.remove(block)
        for block in bpy.data.textures:
            bpy.data.textures.remove(block)
        for block in bpy.data.node_groups:
            bpy.data.node_groups.remove(block)
        for collection in bpy.data.collections:
            bpy.data.collections.remove(collection)
    except Exception as e:
        log(f"Warning: Error clearing scene: {e}", "WARNING")


def has_alpha_channel(image):
    """Check if image actually uses alpha channel (has transparency)."""
    try:
        if not image or not image.pixels:
            return False
        if len(image.pixels) % 4 != 0:
            return False

        pixels = image.pixels[:]
        alpha_values = pixels[3::4]
        sample_step = max(1, len(alpha_values) // 1000)

        for i in range(0, len(alpha_values), sample_step):
            if alpha_values[i] < 0.98:
                return True
        return False
    except Exception:
        return False


def resolve_effective_format(texture_format, file_type):
    """
    Resolve the effective texture format for a given file type.

    VRM files never use WebP (most VRM viewers don't support it).
    When the user picks AUTO or WEBP but we're processing a VRM,
    the effective lossy format falls back to JPEG.

    Returns the effective format string to use for format decisions.
    """
    is_vrm = (file_type == 'vrm')

    if texture_format == 'WEBP' and is_vrm:
        return 'JPEG'  # VRM can't use WebP -> fall back to JPEG
    if texture_format == 'AUTO' and is_vrm:
        return 'AUTO_VRM'  # Special marker: AUTO mode but VRM-safe
    return texture_format


def get_texture_format(image_name, node_type=None, image=None,
                       effective_format='AUTO', aggressive_jpeg=True):
    """
    Determine optimal texture format based on image type and actual usage.

    effective_format values:
        'PNG', 'JPEG', 'WEBP'  - forced format
        'AUTO'                  - smart selection, WebP preferred for lossy
        'AUTO_VRM'              - smart selection, JPEG preferred (VRM-safe)
    """
    # Forced formats
    if effective_format == 'PNG':
        return 'PNG'
    elif effective_format == 'JPEG':
        return 'JPEG'
    elif effective_format == 'WEBP':
        if is_webp_supported():
            return 'WEBP'
        return 'JPEG'

    # AUTO or AUTO_VRM - smart selection
    # Decide which lossy format to use
    is_vrm_safe = (effective_format == 'AUTO_VRM')
    if is_vrm_safe or not is_webp_supported():
        lossy_format = 'JPEG'
    else:
        lossy_format = 'WEBP'

    name_lower = image_name.lower()

    # Normal maps, roughness, metallic need precision -> PNG always
    if any(kw in name_lower for kw in ['normal', 'nrm', 'bump', 'roughness', 'metallic']):
        return 'PNG'

    if aggressive_jpeg:
        # WebP handles alpha natively so it can replace PNG too
        # JPEG cannot, so for JPEG we need to check alpha
        if lossy_format == 'WEBP':
            return 'WEBP'
        else:
            # JPEG path: keep PNG only if image actually has alpha
            if image and has_alpha_channel(image):
                return 'PNG'
            return 'JPEG'
    else:
        # Conservative: keep PNG for anything that hints at alpha
        if any(kw in name_lower for kw in ['alpha', 'opacity', 'mask']):
            return 'PNG'
        return lossy_format


def clean_material_properties(material, verbose=False):
    """Remove specular tint and reduce specular to 0."""
    try:
        if not material.use_nodes:
            if hasattr(material, 'specular_intensity'):
                material.specular_intensity = 0.0
            if hasattr(material, 'specular_color'):
                material.specular_color = (0.0, 0.0, 0.0)
            return

        nodes_to_remove = []
        links_to_remove = []

        for node in material.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                image_name_lower = node.image.name.lower()
                node_name_lower = node.name.lower()
                if any(kw in image_name_lower for kw in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']) or \
                   any(kw in node_name_lower for kw in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']):
                    for output in node.outputs:
                        for link in output.links:
                            links_to_remove.append(link)
                    nodes_to_remove.append(node)

            elif node.type == 'BSDF_PRINCIPLED':
                for input_name in ['Specular', 'Specular IOR Level', 'Specular Tint']:
                    if input_name in node.inputs:
                        specular_input = node.inputs[input_name]
                        try:
                            for link in specular_input.links:
                                links_to_remove.append(link)
                            if hasattr(specular_input, 'default_value'):
                                current_val = specular_input.default_value
                                if input_name == 'Specular Tint':
                                    if isinstance(current_val, (int, float)):
                                        specular_input.default_value = 1.0
                                    else:
                                        specular_input.default_value = (1.0, 1.0, 1.0, 1.0)
                                else:
                                    if isinstance(current_val, (int, float)):
                                        specular_input.default_value = 0.0
                                    else:
                                        specular_input.default_value = (0.0, 0.0, 0.0, 1.0)
                        except Exception:
                            pass

            elif node.type in ['BSDF_GLOSSY', 'BSDF_ANISOTROPIC']:
                nodes_to_remove.append(node)

        for link in links_to_remove:
            try:
                material.node_tree.links.remove(link)
            except Exception:
                pass

        for node in nodes_to_remove:
            try:
                material.node_tree.nodes.remove(node)
            except Exception:
                pass

    except Exception as e:
        log(f"Warning: Error cleaning material '{material.name}': {e}", "WARNING")


def apply_texture_compression(image, target_format, jpeg_quality=80, webp_quality=80,
                              force_compression=True, verbose=False):
    """Apply texture compression by setting format and compressing via file save/reload."""
    try:
        if not image:
            return

        original_format = image.file_format
        was_packed = image.packed_file is not None

        if target_format in ('JPEG', 'WEBP'):
            quality = webp_quality if target_format == 'WEBP' else jpeg_quality
            ext = '.webp' if target_format == 'WEBP' else '.jpg'

            image.file_format = target_format

            if force_compression or original_format != target_format:
                try:
                    import tempfile as _tempfile
                    temp_dir = _tempfile.gettempdir()
                    safe_name = "".join(c for c in image.name if c.isalnum() or c in ('_', '-'))
                    temp_file = os.path.join(temp_dir, f"temp_{safe_name}{ext}")

                    original_quality = bpy.context.scene.render.image_settings.quality
                    original_render_format = bpy.context.scene.render.image_settings.file_format

                    bpy.context.scene.render.image_settings.file_format = target_format
                    bpy.context.scene.render.image_settings.quality = quality

                    image.filepath_raw = temp_file
                    image.save_render(temp_file)

                    bpy.context.scene.render.image_settings.quality = original_quality
                    bpy.context.scene.render.image_settings.file_format = original_render_format

                    image.filepath = temp_file
                    image.source = 'FILE'
                    image.reload()

                    if was_packed:
                        image.pack()

                    try:
                        os.remove(temp_file)
                    except Exception:
                        pass

                    if verbose:
                        log(f"Compressed '{image.name}' to {target_format} @ quality {quality}%")

                except Exception as e:
                    if verbose:
                        log(f"Warning: Could not compress '{image.name}': {e}")

        elif target_format == 'PNG':
            image.file_format = 'PNG'

        image.update()

    except Exception as e:
        log(f"Warning: Error applying compression to '{image.name}': {e}", "WARNING")


def process_material_textures(material, settings):
    """Process all textures in a material using settings dict."""
    if not material.use_nodes:
        return 0

    processed_count = 0

    for node in material.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image:
            image = node.image

            if '_bulk_processed' in image and image['_bulk_processed']:
                continue

            image_name_lower = image.name.lower()
            node_name_lower = node.name.lower()
            if any(kw in image_name_lower for kw in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']) or \
               any(kw in node_name_lower for kw in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']):
                continue

            original_packed = image.packed_file is not None

            target_format = get_texture_format(
                image.name, node.type, image,
                effective_format=settings['effective_format'],
                aggressive_jpeg=settings['aggressive_jpeg']
            )

            apply_texture_compression(
                image, target_format,
                jpeg_quality=settings['jpeg_quality'],
                webp_quality=settings['webp_quality'],
                force_compression=settings['force_compression'],
                verbose=settings['verbose']
            )

            processed_count += 1

            target_res = settings['target_resolution']
            if image.size[0] > target_res or image.size[1] > target_res:
                image.scale(target_res, target_res)
                image.update()

            if original_packed and not image.packed_file:
                try:
                    image.pack()
                except Exception:
                    pass

            image['_bulk_processed'] = True

    return processed_count


def get_file_type(filepath):
    """Determine file type based on extension."""
    ext = Path(filepath).suffix.lower()
    if ext in ['.glb', '.gltf']:
        return 'gltf'
    elif ext == '.vrm':
        return 'vrm'
    return 'unknown'


def import_file(input_path, verbose=False):
    """Import file based on its type."""
    file_type = get_file_type(input_path)

    if file_type == 'gltf':
        try:
            bpy.ops.import_scene.gltf(filepath=str(input_path))
            return True
        except Exception as e:
            log(f"Error importing GLTF/GLB '{input_path}': {e}", "ERROR")
            if "bone" in str(e).lower() or "animation" in str(e).lower():
                try:
                    bpy.ops.import_scene.gltf(filepath=str(input_path), import_pack_images=True)
                    return True
                except Exception:
                    return False
            return False

    elif file_type == 'vrm':
        try:
            bpy.ops.import_scene.vrm(filepath=str(input_path))
            return True
        except Exception as e:
            log(f"Error importing VRM '{input_path}': {e}", "ERROR")
            return False

    return False


def export_file(output_path, file_type, verbose=False):
    """Export file based on desired output type."""
    try:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

        if file_type == 'vrm':
            bpy.ops.export_scene.vrm(filepath=str(output_path))

        elif file_type == 'gltf':
            try:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLTF_SEPARATE',
                    export_materials='EXPORT',
                    export_colors=True,
                    export_cameras=False,
                    export_lights=False,
                    export_animations=True,
                    export_yup=True,
                    export_apply=False,
                    export_texcoords=True,
                    export_normals=True,
                    export_draco_mesh_compression_enable=False,
                    export_tangents=False,
                    use_selection=False,
                    use_visible=False,
                    use_renderable=False,
                    use_active_collection=False,
                    use_active_scene=False
                )
            except TypeError:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLTF_SEPARATE'
                )
        else:
            try:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLB',
                    export_materials='EXPORT',
                    export_colors=True,
                    export_cameras=False,
                    export_lights=False,
                    export_animations=True,
                    export_yup=True,
                    export_apply=False,
                    export_texcoords=True,
                    export_normals=True,
                    export_draco_mesh_compression_enable=False,
                    export_tangents=False,
                    use_selection=False,
                    use_visible=False,
                    use_renderable=False,
                    use_active_collection=False,
                    use_active_scene=False
                )
            except TypeError:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLB'
                )
        return True

    except Exception as e:
        log(f"Error exporting '{output_path}': {e}", "ERROR")
        return False


def get_file_size_mb(filepath):
    """Get file size in megabytes."""
    try:
        return os.path.getsize(filepath) / (1024 * 1024)
    except Exception:
        return 0


# ================================
# BLENDER ADDON PROPERTIES
# ================================

class BatchOptimizerProperties(bpy.types.PropertyGroup):
    input_dir: StringProperty(
        name="Input Directory",
        description="Directory containing .glb, .gltf, and .vrm files to process",
        default="",
        subtype='DIR_PATH'
    )
    output_dir: StringProperty(
        name="Output Directory",
        description="Directory for processed output files",
        default="",
        subtype='DIR_PATH'
    )
    target_resolution: IntProperty(
        name="Target Resolution",
        description="Target texture resolution (width & height)",
        default=512,
        min=32,
        max=4096
    )
    skip_existing: BoolProperty(
        name="Skip Existing",
        description="Skip files that already exist in output directory",
        default=True
    )
    texture_format: EnumProperty(
        name="Texture Format",
        description="Texture compression format",
        items=[
            ('AUTO', "Auto",
             "Smart: WebP for GLB/GLTF, JPEG for VRM (VRM viewers don't support WebP). "
             "PNG for normal maps"),
            ('JPEG', "JPEG", "JPEG for all files (no alpha support)"),
            ('PNG', "PNG", "PNG for all files (lossless, larger)"),
            ('WEBP', "WebP",
             "WebP for GLB/GLTF, auto-falls back to JPEG for VRM files. "
             "Requires Blender 3.4+"),
        ],
        default='AUTO'
    )
    jpeg_quality: IntProperty(
        name="JPEG Quality",
        description="JPEG compression quality — used for all JPEG textures and as VRM fallback quality",
        default=80,
        min=1,
        max=100
    )
    webp_quality: IntProperty(
        name="WebP Quality",
        description="WebP compression quality — used for GLB/GLTF textures",
        default=80,
        min=1,
        max=100
    )
    preserve_format: BoolProperty(
        name="Preserve Format",
        description="Keep original file format (GLTF stays GLTF). Otherwise converts to GLB",
        default=False
    )
    remove_specular: BoolProperty(
        name="Remove Specular",
        description="Remove specular tint textures and set specular to 0",
        default=True
    )
    aggressive_jpeg: BoolProperty(
        name="Aggressive Lossy Conversion",
        description="Aggressively convert PNG textures to lossy format when alpha is not needed",
        default=True
    )
    force_compression: BoolProperty(
        name="Force Compression",
        description="Force texture compression even when not resizing",
        default=True
    )
    verbose: BoolProperty(
        name="Verbose Logging",
        description="Enable detailed logging in the console",
        default=True
    )


# ================================
# BLENDER ADDON OPERATOR
# ================================

class BATCH_OT_optimize(bpy.types.Operator):
    """Batch optimize 3D files in the input directory"""
    bl_idname = "batch_optimizer.optimize"
    bl_label = "Optimize Files"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.batch_optimizer

        # Validate
        input_dir = bpy.path.abspath(props.input_dir)
        output_dir = bpy.path.abspath(props.output_dir)

        if not input_dir or not os.path.isdir(input_dir):
            self.report({'ERROR'}, f"Input directory does not exist: {input_dir}")
            return {'CANCELLED'}

        if not output_dir:
            self.report({'ERROR'}, "Output directory is not set")
            return {'CANCELLED'}

        # Check WebP compatibility
        if props.texture_format in ('WEBP', 'AUTO') and not is_webp_supported():
            self.report({'WARNING'},
                        f"WebP not supported in Blender {bpy.app.version_string} (requires 3.4+). "
                        f"All lossy textures will use JPEG.")

        os.makedirs(output_dir, exist_ok=True)

        input_path = Path(input_dir)
        output_path = Path(output_dir)

        # Find files
        files = (
            list(input_path.glob("*.glb")) + list(input_path.glob("*.GLB")) +
            list(input_path.glob("*.gltf")) + list(input_path.glob("*.GLTF")) +
            list(input_path.glob("*.vrm")) + list(input_path.glob("*.VRM"))
        )

        if not files:
            self.report({'WARNING'}, "No .glb, .gltf, or .vrm files found in input directory")
            return {'CANCELLED'}

        processed = 0
        skipped = 0
        errors = 0
        total_before = 0.0
        total_after = 0.0

        for i, f in enumerate(files, 1):
            log(f"\n--- Processing file {i}/{len(files)}: {f.name} ---")

            # Determine file type
            ftype = get_file_type(f)

            # Resolve the effective texture format for this file type
            # This is where VRM gets JPEG instead of WebP
            effective_format = resolve_effective_format(props.texture_format, ftype)

            if props.verbose:
                if ftype == 'vrm' and props.texture_format in ('WEBP', 'AUTO'):
                    log(f"VRM file detected — using JPEG instead of WebP for texture compression")
                log(f"Effective texture format for '{f.name}': {effective_format}")

            # Build settings dict with the per-file effective format
            settings = {
                'target_resolution': props.target_resolution,
                'effective_format': effective_format,
                'jpeg_quality': props.jpeg_quality,
                'webp_quality': props.webp_quality,
                'force_compression': props.force_compression,
                'aggressive_jpeg': props.aggressive_jpeg,
                'verbose': props.verbose,
            }

            # Determine output filename
            if ftype == 'vrm':
                out_name = f.stem + '.vrm'
            elif props.preserve_format:
                out_name = f.name
            else:
                out_name = f.stem + '.glb'

            out_file = output_path / out_name

            if props.skip_existing and out_file.exists():
                log(f"Skipping existing: {out_file.name}")
                skipped += 1
                continue

            original_size = get_file_size_mb(f)
            total_before += original_size

            # Process
            try:
                clear_scene()

                if not import_file(f, verbose=props.verbose):
                    errors += 1
                    continue

                if props.remove_specular:
                    for mat in bpy.data.materials:
                        if mat.users > 0:
                            clean_material_properties(mat, verbose=props.verbose)

                total_tex = 0
                for mat in bpy.data.materials:
                    if mat.users > 0:
                        total_tex += process_material_textures(mat, settings)

                log(f"Processed {total_tex} textures")

                # Export
                if ftype == 'vrm':
                    success = export_file(str(out_file), 'vrm', verbose=props.verbose)
                elif props.preserve_format and ftype == 'gltf' and out_file.suffix.lower() == '.gltf':
                    success = export_file(str(out_file), 'gltf', verbose=props.verbose)
                else:
                    success = export_file(str(out_file), 'glb', verbose=props.verbose)

                if success:
                    processed += 1
                    new_size = get_file_size_mb(out_file)
                    total_after += new_size
                    ratio = ((original_size - new_size) / original_size * 100) if original_size > 0 else 0
                    log(f"Size: {original_size:.2f}MB -> {new_size:.2f}MB ({ratio:+.1f}%)")
                else:
                    errors += 1

            except Exception as e:
                log(f"Error processing '{f.name}': {e}", "ERROR")
                traceback.print_exc()
                errors += 1

        # Summary
        overall = ((total_before - total_after) / total_before * 100) if total_before > 0 else 0
        summary = (
            f"Done! Processed: {processed}, Skipped: {skipped}, Errors: {errors}. "
            f"Size: {total_before:.1f}MB -> {total_after:.1f}MB ({overall:+.1f}%)"
        )
        log(f"\n{'='*50}")
        log(summary)
        self.report({'INFO'}, summary)

        return {'FINISHED'}


# ================================
# BLENDER ADDON UI PANEL
# ================================

class BATCH_PT_optimizer_panel(bpy.types.Panel):
    """3D Batch Optimizer Panel"""
    bl_label = "3D Batch Optimizer"
    bl_idname = "BATCH_PT_optimizer_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = '3D Batch Optimizer'

    def draw(self, context):
        layout = self.layout
        props = context.scene.batch_optimizer

        # Header info
        box = layout.box()
        box.label(text="3D Batch Optimizer v2.1", icon='MODIFIER')
        row = box.row()
        row.label(text=f"Blender {bpy.app.version_string}")
        if is_webp_supported():
            row.label(text="WebP: Yes", icon='CHECKMARK')
        else:
            row.label(text="WebP: No (needs 3.4+)", icon='ERROR')

        # Directories
        box = layout.box()
        box.label(text="Directories", icon='FILE_FOLDER')
        box.prop(props, "input_dir")
        box.prop(props, "output_dir")

        # Texture Settings
        box = layout.box()
        box.label(text="Texture Settings", icon='TEXTURE')
        box.prop(props, "target_resolution")
        box.prop(props, "texture_format")

        # Format info box
        if props.texture_format in ('AUTO', 'WEBP'):
            info_box = box.box()
            col = info_box.column(align=True)
            col.scale_y = 0.8
            if props.texture_format == 'AUTO':
                col.label(text="GLB/GLTF: WebP  |  VRM: JPEG", icon='INFO')
                col.label(text="Normal/roughness maps: PNG")
            else:
                col.label(text="GLB/GLTF: WebP  |  VRM: JPEG (auto)", icon='INFO')

        # Show quality sliders based on format
        # Always show JPEG quality when VRM files could be in the batch
        if props.texture_format in ('JPEG', 'AUTO', 'WEBP'):
            box.prop(props, "jpeg_quality", slider=True)
        if props.texture_format in ('WEBP', 'AUTO'):
            box.prop(props, "webp_quality", slider=True)

        # Options
        box = layout.box()
        box.label(text="Options", icon='PREFERENCES')
        col = box.column(align=True)
        col.prop(props, "skip_existing")
        col.prop(props, "preserve_format")
        col.prop(props, "remove_specular")
        col.prop(props, "aggressive_jpeg")
        col.prop(props, "force_compression")
        col.prop(props, "verbose")

        # Run button
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 2.0
        row.operator("batch_optimizer.optimize", text="OPTIMIZE FILES", icon='PLAY')


# ================================
# REGISTRATION
# ================================

classes = (
    BatchOptimizerProperties,
    BATCH_OT_optimize,
    BATCH_PT_optimizer_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.batch_optimizer = bpy.props.PointerProperty(type=BatchOptimizerProperties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.batch_optimizer


if __name__ == "__main__":
    register()
